#include <Arduino.h>
#include "LedToggleClass.h"
//Ticker LedON;
//Ticker LedOFF;
//uint32_t ONperiod;
//uint32_t OFFperiod;
//bool _activeLow;
//int LED_PIN;
void LedToggle:: Toggle() {
 
  if (isON && OFFperiod!=0) {
    _LedOFF();
    time_event = millis() + OFFperiod;
  }
  else if ((!isON) && (ONperiod!=0))
  {
    _LedON();
    time_event = millis() + ONperiod;
  }
  else
  {
    return;
  }
}
void LedToggle:: Handle()
{
  if (isEnabled) {
    if (millis() >= time_event)
    {
      Toggle();
    }
  }
}

void LedToggle::Set(int pin, LedType ledAct, uint32_t Ton_ms, uint32_t Toff_ms)
{
  isON = false;
  LED_PIN = pin;
  _ledAct = ledAct;
  ONperiod = Ton_ms;
  OFFperiod = Toff_ms;
  pinMode(LED_PIN, OUTPUT);
}
void LedToggle::Start()
{
  isEnabled = true;
  _LedOFF();
  Toggle();
}
void LedToggle::Stop()
{
  isEnabled = false;
}
void LedToggle::Dispose()
{
  Stop();
  pinMode(LED_PIN, INPUT);
}
bool LedToggle::GetState()
{
 return isON;
}
void LedToggle::_LedON()
{
  if (_ledAct == activeLow) {
    digitalWrite(LED_PIN, LOW);
  } else {
    digitalWrite(LED_PIN, HIGH);
  }
  isON = true;
}
void LedToggle::_LedOFF()
{
  if (_ledAct == activeLow) {
    digitalWrite(LED_PIN, HIGH);
  } else {
    digitalWrite(LED_PIN, LOW);
  }
  isON = false;
}
