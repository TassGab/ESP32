#ifndef CLIclass_h
#define CLIclass_h
#define LINE_BUF_SIZE 128   //Maximum input string length
#define ARG_BUF_SIZE 64     //Maximum argument string length
#define MAX_NUM_ARGS 8      //Maximum number of arguments
class CLIclass
{
  public:
    bool Handle();
   // void SetCommands(char *_commands_str[], int ncom);//List of command names
//    void SetFunctions(int (*_commands_func[])(), int ncom); //List of function pointers
//    int (* FuncToExe())();
    
    char argms[MAX_NUM_ARGS][ARG_BUF_SIZE];
    int GetCmdIdx(char *_commands_str[],int num_commands);
    Stream *instr;
  private:
    void serialEvent();
    void parse_line();    
    char line[LINE_BUF_SIZE];
    
    String inputString = "";         // a String to hold incoming data
    bool stringComplete = false;  // whether the string is complete
    bool error_flag = false;
    //char *commands_str[];
    //int (*commands_func[])();

};

#endif
