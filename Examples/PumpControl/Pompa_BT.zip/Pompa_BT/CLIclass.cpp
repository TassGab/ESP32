#include <Arduino.h>
#include "CLIclass.h"

#include "esp32-hal-log.h"

//int n_commands=0;
static const char* TAG = "MyModule";
bool CLIclass::Handle()
{
  bool result = false;
  if (instr->available()) serialEvent();
  if (stringComplete) {
    //ESP_LOGI(TAG,inputString);
    // clear the string:
    //line_string = inputString;


    if (inputString.length() < LINE_BUF_SIZE) {
      inputString.toCharArray(line, LINE_BUF_SIZE);
      //ESP_LOGI(TAG,inpuString);
      error_flag = false;
    }
    else {
      ESP_LOGI(TAG,"Input string too long.");
      error_flag = true;
    }
    memset(argms, 0, sizeof(argms[0][0]) * MAX_NUM_ARGS * ARG_BUF_SIZE);
    if (!error_flag) {
      parse_line();
    }
    if (!error_flag) {
      result = true;

    }

    memset(line, 0, LINE_BUF_SIZE);
    

    error_flag = false;
    inputString = "";
    stringComplete = false;
  }
  return result;
}
void CLIclass::serialEvent() {
  while (instr->available()) {
    // get the new byte:
    char inChar = (char)instr->read();
    // if the incoming character is a newline, set a flag so the main loop can
    // do something about it:
    int slen=inputString.length();
    if ((inChar == '\n' || inChar == '\r') && slen>0 ) {
      stringComplete = true;

      //inputString += " "; //add space for parser
      return;
    }
    if((inChar == '\n' || inChar == '\r') && slen==0 ) {
      return; //discard \n or \r alone
    }
    // add it to the inputString:
    inputString += inChar;

  }
}

void CLIclass::parse_line() {
  char *argument;
  int counter = 0;

  argument = strtok(line, " ");
  //ESP_LOGI(TAG,argument);
  while ((argument != NULL)) {
    if (counter < MAX_NUM_ARGS) {
      if (strlen(argument) < ARG_BUF_SIZE) {
        strcpy(argms[counter], argument);
        argument = strtok(NULL, " ");

        ESP_LOGI(TAG,"arg =%s",argms[counter]); 
        counter++;
      }
      else {
        ESP_LOGI(TAG,"Input string too long.");
        error_flag = true;
        break;
      }
    }
    else {
      ESP_LOGI(TAG,"Too many argms");
      break;
    }
  }
}

//void CLIclass::SetCommands(char *_commands_str[], int ncom)
//{ //List of command names
//
// // inputString.reserve(LINE_BUF_SIZE);
//  n_commands = ncom;
////  ESP_LOGI(TAG,"Numero di comandi="); ESP_LOGI(TAG,n_commands);
//  char buf[32];
////  sprintf(buf,"addr=%p",&n_commands);ESP_LOGI(TAG,buf);
//  int ic = 0;
//  //ESP_LOGI(TAG,"Numero di comandi="); ESP_LOGI(TAG,num_commands);
//  for (ic = 0; ic < n_commands; ic++) {
//    commands_str[ic] = _commands_str[ic];
//   //ESP_LOGI(TAG,"cmd=");ESP_LOGI(TAG,ic);ESP_LOGI(TAG," ->"); ESP_LOGI(TAG,commands_str[ic]);ESP_LOGI(TAG,".");
//  }
//}

int CLIclass::GetCmdIdx(char *_commands_str[], int n_commands)
{
  int ic=0;
//  ESP_LOGI(TAG,"n max com="); ESP_LOGI(TAG,n_commands);
//  char buf[32];
//  sprintf(buf,"addr=%p",&n_commands);ESP_LOGI(TAG,buf);
//  for (ic = 0; ic < n_commands; ic++) {
//    ESP_LOGI(TAG,"arg "); ESP_LOGI(TAG,argms[ic]);ESP_LOGI(TAG,".");
//    ESP_LOGI(TAG,"cmd "); ESP_LOGI(TAG,_commands_str[ic]);ESP_LOGI(TAG,".");
//  }
  for (ic = 0; ic < n_commands; ic++) {
    //ESP_LOGI(TAG,"arg 0="); ESP_LOGI(TAG,argms[0]);ESP_LOGI(TAG,".");
    //ESP_LOGI(TAG,"compare with="); ESP_LOGI(TAG,commands_str[ic]);ESP_LOGI(TAG,".");
    if (strcmp(argms[0], _commands_str[ic]) == 0) {
//      ESP_LOGI(TAG,"cmd="); ESP_LOGI(TAG,_commands_str[ic]);
      return ic;
    }
  }
  ESP_LOGI(TAG,"Invalid command. Type \"help\" for more.");
  return 0;
}
