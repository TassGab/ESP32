#ifndef LedToggle_h
#define LedToggle_h

enum LedType
{
  activeLow,
  activeHi
};
class LedToggle
{
  public:
    void Set(int pin, LedType ledAct, uint32_t Ton_ms, uint32_t Toff_ms);
    void Start();
    void Stop();
    void Dispose();
    void Handle();
    bool isEnabled;
    bool GetState();
  protected:
    uint32_t ONperiod;
    uint32_t OFFperiod;    
    int LED_PIN;
    void Toggle();
    bool isON;
    LedType _ledAct;
    unsigned long time_event;
    void _LedON();
    void _LedOFF();
};

#endif
